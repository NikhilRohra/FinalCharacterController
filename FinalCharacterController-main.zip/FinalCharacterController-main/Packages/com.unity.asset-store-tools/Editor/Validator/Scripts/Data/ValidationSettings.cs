﻿using System.Collections.Generic;

namespace AssetStoreTools.Validator.Data
{
    internal class ValidationSettings
    {
        public List<string> ValidationPaths;
        public string Category;
    }
}