using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Unity.AssetStoreTools.Editor.Tests.asmdef")]
[assembly: InternalsVisibleTo("ab-builder")]